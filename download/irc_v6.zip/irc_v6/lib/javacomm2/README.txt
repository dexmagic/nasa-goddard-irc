This directory used to be named lib/javacomm.  See http://wiki.gb.nrao.edu/bin/view/Pennarray/JavaComm3 for the reason for the change.

Steve Maher
5.1.06
