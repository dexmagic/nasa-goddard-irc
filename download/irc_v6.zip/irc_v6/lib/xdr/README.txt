From "RemoteTea" http://remotetea.sourceforge.net/.  This only includes
source, so this jar was created from all the classes in the "org.*" packages.

Steve Maher
May 1, 2006