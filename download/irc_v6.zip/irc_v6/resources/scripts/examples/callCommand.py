print "Calling command:", cmdName
publishMessage(cmdName)
