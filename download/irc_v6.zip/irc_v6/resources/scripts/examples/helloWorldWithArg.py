print "Argument one:", argument1
print "Argument two:", argument2
print "Argument three:", argument3
print "Argument four:", argument4