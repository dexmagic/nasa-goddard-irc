//=== File Prolog ============================================================
//
//	This code was developed by NASA, Goddard Space Flight Center, Code 580
//	for the Instrument Remote Control (IRC) project.
//
//--- Notes ------------------------------------------------------------------
//  Development history is located at the end of the file.
//
//--- Warning ----------------------------------------------------------------
//	This software is property of the National Aeronautics and Space
//	Administration. Unauthorized use or duplication of this software is
//	strictly prohibited. Authorized users are subject to the following
//	restrictions:
//	*	Neither the author, their corporation, nor NASA is responsible for
//		any consequence of the use of this software.
//	*	The origin of this software must not be misrepresented either by
//		explicit claim or by omission.
//	*	Altered versions of this software must be plainly marked as such.
//	*	This notice may not be removed or altered.
//
//=== End File Prolog ========================================================

package gov.nasa.gsfc.commons.processing.activity;

/**
 * HasException is an indicator that the implemention supports an exception 
 * state. The exception state can be queried and cleared.
 *
 * <P>This code was developed for NASA, Goddard Space Flight Center, Code 580
 * for the Instrument Remote Control (IRC) project.
 *
 * @version	$Date: 2005/04/16 03:56:18 $
 * @author 	Troy Ames
 */
public interface HasException
{
	/**
	 * Returns true if this Object is in an exception state, false otherwise.
	 *
	 * @return True if this Object is in an exception state, false otherwise
	 */
	public boolean isException();
	
	/**
	 * If this Object is in an exception state, this method will return the 
	 * Exception that caused it. Otherwise, it returns null.
	 *  
	 * @return The Exception that caused the exception state
	 */
	public Exception getException();
	
	/**
	 * Clears the current Exception (if any) from this Object.
	 */
	public void clearException();
}


//--- Development History  ---------------------------------------------------
//
//  $Log: HasException.java,v $
//  Revision 1.1  2005/04/16 03:56:18  tames
//  Refactored activity package.
//
//